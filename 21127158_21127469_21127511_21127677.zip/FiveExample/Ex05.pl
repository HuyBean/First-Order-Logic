% Querying built-in predicates
?- member(2, [1, 2, 3]).
?- sort([3, 1, 2], SortedList).