# First-Order-Logic
Artificial Intelligence

Members: 
Nguyen Quoc Huy
Vo Thanh Tu
Le Hoang Sang
Vo Pham Thanh Phuong